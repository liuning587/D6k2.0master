
#ifndef RDB_DEFINE_H
#define RDB_DEFINE_H

#define U32INT unsigned int

enum
{
	DI_TYPE = 100,		// 100
	AI_TYPE = 200,		// 200
	DD_TYPE = 300,		// 300
	CALC_TYPE = 400,	// 400
};

#endif // RDB_DEFINE_H